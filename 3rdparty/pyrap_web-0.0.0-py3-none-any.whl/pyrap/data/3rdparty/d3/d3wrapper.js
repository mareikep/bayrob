if (typeof d3 === 'undefined') {
    {d3content}
}